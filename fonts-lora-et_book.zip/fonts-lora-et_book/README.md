Fonts originally taken from these places:

- https://fonts.google.com/specimen/Lora
- https://github.com/edwardtufte/et-book

Unpack, install, enjoy.
